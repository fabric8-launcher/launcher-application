# rest-vertx

Created by the Cloud App Generator
